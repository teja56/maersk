package com.qa.blazedemo.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.blazedemo.Utilities.ConfigReader;
import com.qa.blazedemo.Utilities.CsvReader;
import com.qa.blazedemo.Utilities.HelperUtil;
import com.qa.blazedemo.Utilities.LogUtil;
import com.qa.blazedemo.base.BookingDetailsBuilder;
import com.qa.blazedemo.pages.ConfirmationPage;
import com.qa.blazedemo.pages.HomePage;
import com.qa.blazedemo.pages.PurchasePage;
import com.qa.blazedemo.pages.ReservePage;

import java.util.List;
import java.io.File;

public class BookAFlightTest extends BaseTest {

	private static Logger _log = LogManager.getLogger(BookAFlightTest.class);
	private String testCaseName = this.getClass().getName().trim();

	private CsvReader readCsv = new CsvReader();
	private String baseUrl = ConfigReader.get("baseURL");

	public HomePage homePage;
	public ReservePage reservePage;
	public PurchasePage purchasePage;
	public ConfirmationPage confirmationPage;
	public HelperUtil helperUtil;

	@BeforeClass
	public void setup() {
		LogUtil.info("End to End testcases for Booking a flight");
		LogUtil.startTestCase(testCaseName);
		homePage = PageFactory.initElements(driver, HomePage.class);
		reservePage = PageFactory.initElements(driver, ReservePage.class);
		purchasePage = PageFactory.initElements(driver, PurchasePage.class);
		confirmationPage = PageFactory.initElements(driver, ConfirmationPage.class);
		helperUtil = new HelperUtil(driver);
	}

	@DataProvider(name = "bookingFlight")
	public Object[][] bookFlightsData() {
		Object[][] rawData;
		List<String[]> bookFlights = readCsv
				.parseFile(new File(ConfigReader.get("BookingDetailsCSV")).getAbsolutePath());
		rawData = new Object[bookFlights.size()][1];

		for (int i = 0; i < bookFlights.size(); i++) {
			for (String[] bookFlight : bookFlights) {
				rawData[i++][0] = new BookingDetailsBuilder(bookFlight);
			}
		}
		return rawData;
	}

	@Test(description = "Search for flights", dataProvider = "bookingFlight")
	public void searchForFlights(BookingDetailsBuilder data) {
		helperUtil.navigatePage(baseUrl);
		homePage.selectDepartureCity(data.getBookingDetails().getDeparture());
		homePage.selectDesitinationCity(data.getBookingDetails().getDestination());
		homePage.findFlights();
	}

	@Test(description = "Choose Low cost airline", dependsOnMethods = "searchForFlights", dataProvider = "bookingFlight")
	public void chooseLowestPricedAirline(BookingDetailsBuilder data) {
		reservePage.verifyReservePageDisplayed();
		reservePage.flyLowCostAirLine();
	}

	@Test(description = "Enter details and purchase a ticket", dependsOnMethods = "chooseLowestPricedAirline", dataProvider = "bookingFlight")
	public void purchaseFlightTicket(BookingDetailsBuilder data) {
		purchasePage.verifyPurchasePageDisplayed();
		purchasePage.enterFlyerName(data.getBookingDetails().getName());
		purchasePage.enterFlyerAddress(data.getBookingDetails().getAddress());
		purchasePage.enterFlyerCity(data.getBookingDetails().getCity());
		purchasePage.enterFlyerState(data.getBookingDetails().getState());
		purchasePage.enterFlyerZipCode(data.getBookingDetails().getZipCode());
		purchasePage.enterFlyerCardNumber(data.getBookingDetails().getCardNumber());
		purchasePage.enterFlyerCardMonth(data.getBookingDetails().getMonth());
		purchasePage.enterFlyerCardYear(data.getBookingDetails().getYear());
		purchasePage.enterFlyerCardName(data.getBookingDetails().getCardName());
		purchasePage.clickPurchaseFlights();
	}

	@Test(description = "Confirmation page displayed on purchase", dependsOnMethods = "purchaseFlightTicket")
	public void bookingConfirmed() {
		confirmationPage.verifyConfirmationPageDisplayed();
	}

	@Test(description = "Confirmation Id displayed after purchase", dependsOnMethods = "bookingConfirmed")
	public void bookingConfirmedId() {
		confirmationPage.verifyConfirmationIdDisplayed();
	}

	@AfterTest(description = "After test info")
	public void afterTest() {
		LogUtil.endTestCase(testCaseName);
		driver.quit();
	}

}
