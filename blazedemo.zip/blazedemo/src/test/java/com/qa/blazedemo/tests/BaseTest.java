package com.qa.blazedemo.tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import com.qa.blazedemo.Utilities.ConfigReader;
import com.qa.blazedemo.Utilities.ConfigWriter;

public class BaseTest {

	public static WebDriver driver;

	private static Logger _log = LogManager.getLogger(BaseTest.class);

	@BeforeSuite(alwaysRun = true)
	void Config() {
		ConfigWriter.setPropertyValue("logger.file", "webLogger", ConfigReader.get("config.path"));
	}

	@Parameters({ "browser" })
	@BeforeClass
	public void launchBrowser(String browserName) {
		try {
			if (browserName.equals("chrome")) {
				WebDriverManager.chromedriver().setup();
				driver = new ChromeDriver();
			} else if (browserName.equals("firefox")) {
				WebDriverManager.firefoxdriver().setup();
				driver = new FirefoxDriver();
			} else if (browserName.equals("edge")) {
				WebDriverManager.edgedriver().setup();
				driver = new EdgeDriver();
			} else if (browserName.equals("iexplorer")) {
				WebDriverManager.iedriver().setup();
				driver = new InternetExplorerDriver();
			}
			driver.manage().window().setPosition(new Point(0, 0));
			Dimension d = new Dimension(1300, 900);
			driver.manage().window().setSize(d);
		} catch (WebDriverException e) {
			System.out.println(e.getMessage());
		}

	}

	@AfterClass
	public void tearDownBrowser() {
		driver.quit();
	}
}
