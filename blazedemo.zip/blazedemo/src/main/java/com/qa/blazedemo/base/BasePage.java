package com.qa.blazedemo.base;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;
import com.qa.blazedemo.Utilities.ConfigReader;
import com.qa.blazedemo.Utilities.ConfigWriter;


public abstract class BasePage {

    public WebDriver driver;
    private static final Logger log = LogManager.getLogger(BasePage.class);

    public BasePage(WebDriver driver){
        this.driver = driver;
    }

    @BeforeSuite(alwaysRun = true)
    void Config() {
        ConfigWriter.setPropertyValue("logger.file", "webLogger", ConfigReader.get("config.path"));
    }
}