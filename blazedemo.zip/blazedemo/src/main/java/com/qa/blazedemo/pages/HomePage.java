package com.qa.blazedemo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.blazedemo.Utilities.HelperUtil;
import com.qa.blazedemo.Utilities.WaitUtil;
import com.qa.blazedemo.base.BasePage;

public class HomePage extends BasePage {
	private HelperUtil helperUtil;
	private WaitUtil waitUtil;
	private int explicitTimeOut;

	@FindBy(xpath = "//div[@class='jumbotron']//h1[contains(text(),'Welcome to the Simple Travel Agency!')]")
	WebElement welcomeTitleMessage;

	@FindBy(name = "fromPort")
	WebElement dptDropDown;

	@FindBy(name = "toPort")
	WebElement destnDropDown;

	@FindBy(xpath = "//input[@value='Find Flights']")
	WebElement flightsButton;

	public HomePage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
		waitUtil = new WaitUtil(driver);
		helperUtil = new HelperUtil(driver);
		explicitTimeOut = waitUtil.getExplicitTimeout();
	}

	public void selectDepartureCity(String value) {
		helperUtil.selectByValue(dptDropDown, value);
	}

	public void selectDesitinationCity(String value) {
		helperUtil.selectByValue(destnDropDown, value);
	}

	public void findFlights() {
		waitUtil.isElementVisible(flightsButton, explicitTimeOut);
		flightsButton.click();
	}
}
