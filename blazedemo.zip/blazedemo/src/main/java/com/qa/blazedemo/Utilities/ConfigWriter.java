package com.qa.blazedemo.Utilities;

import java.io.*;
import java.util.Properties;

public class ConfigWriter {

	public static void setPropertyValue(String propKey, String propValue, String path) {

		File file = new File(path);
		Properties prop = new Properties();
		try {
			FileInputStream fileInput = new FileInputStream(file);
			prop.load(fileInput);
			fileInput.close();
			prop.setProperty(propKey, propValue);
			FileOutputStream fileOutput = new FileOutputStream(file);
			prop.store(fileOutput, null);
			fileOutput.close();

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
